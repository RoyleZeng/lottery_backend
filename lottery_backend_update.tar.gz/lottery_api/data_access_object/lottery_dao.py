from lottery_api.data_access_object.db import Database, OracleDatabase
from lottery_api.utils.privacy_protection import apply_privacy_mask
import uuid
import json


class LotteryDAO:
    """Data Access Object for lottery-related operations"""

    @staticmethod
    def _parse_meta(meta_value):
        """Parse meta field from database"""
        if isinstance(meta_value, str):
            try:
                return json.loads(meta_value)
            except (json.JSONDecodeError, TypeError):
                return {}
        elif isinstance(meta_value, dict):
            return meta_value
        else:
            return {}

    @staticmethod
    async def create_lottery_event(conn, academic_year_term, name, description, event_date, type="general", status="pending"):
        """Create a new lottery event"""
        event_id = str(uuid.uuid4())
        query = """
        INSERT INTO lottery_events (id, academic_year_term, name, description, event_date, type, status, is_deleted)
        VALUES ($1, $2, $3, $4, $5, $6, $7, FALSE)
        RETURNING id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
        """
        return await Database.fetchrow(conn, query, event_id, academic_year_term, name, description, event_date, type, status)

    @staticmethod
    async def update_event_status(conn, event_id, status):
        """Update event status"""
        query = """
        UPDATE lottery_events
        SET status = $2
        WHERE id = $1 AND is_deleted = FALSE
        RETURNING id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
        """
        return await Database.fetchrow(conn, query, event_id, status)

    @staticmethod
    async def get_lottery_events(conn, limit=100, offset=0, event_type=None):
        """Get all lottery events with pagination (excluding soft deleted)"""
        if event_type:
            query = """
            SELECT id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
            FROM lottery_events
            WHERE type = $3 AND is_deleted = FALSE
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
            """
            return await Database.fetch(conn, query, limit, offset, event_type)
        else:
            query = """
            SELECT id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
            FROM lottery_events
            WHERE is_deleted = FALSE
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
            """
            return await Database.fetch(conn, query, limit, offset)

    @staticmethod
    async def get_lottery_event_by_id(conn, event_id):
        """Get a lottery event by ID (excluding soft deleted)"""
        query = """
        SELECT id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
        FROM lottery_events
        WHERE id = $1 AND is_deleted = FALSE
        """
        return await Database.fetchrow(conn, query, event_id)

    @staticmethod
    async def add_participant(conn, event_id, participant_data):
        """Add a participant to a lottery event with metadata from Oracle"""
        student_id = participant_data.get('id', '')
        
        # Get student info from Oracle database
        oracle_student_info = OracleDatabase.get_student_info(student_id)
        
        if not oracle_student_info:
            # If student not found in Oracle, skip this participant
            return None
        
        # Prepare meta data with Oracle info
        meta = {
            "student_info": {
                "id": participant_data.get('id', ''),
                "department": participant_data.get('department', ''),
                "name": participant_data.get('name', ''),
                "grade": participant_data.get('grade', '')
            },
            "oracle_info": oracle_student_info
        }
        
        # Add teaching comments if available
        if any(key in participant_data for key in ['required_surveys', 'completed_surveys', 'surveys_completed', 'valid_surveys']):
            meta["teaching_comments"] = {
                "required_surveys": participant_data.get('required_surveys', 0),
                "completed_surveys": participant_data.get('completed_surveys', 0),
                "surveys_completed": participant_data.get('surveys_completed', False),
                "valid_surveys": participant_data.get('valid_surveys', False)
            }
        
        query = """
        INSERT INTO lottery_participants (event_id, meta)
        VALUES ($1, $2)
        RETURNING id, event_id, meta, created_at
        """
        result = await Database.fetchrow(conn, query, event_id, json.dumps(meta))
        if result:
            # Parse meta field
            result['meta'] = LotteryDAO._parse_meta(result['meta'])
        return result

    @staticmethod
    async def add_participants_batch(conn, event_id, participants_data):
        """Batch add participants to a lottery event with Oracle metadata lookup"""
        # Extract all student IDs for batch Oracle lookup
        student_ids = [p.get('id', '') for p in participants_data if p.get('id')]
        
        # Get all student info from Oracle in one batch
        oracle_students = OracleDatabase.get_students_batch(student_ids)
        
        # Prepare batch insert data
        batch_data = []
        skipped_students = []
        
        for participant_data in participants_data:
            student_id = participant_data.get('id', '')
            oracle_student_info = oracle_students.get(student_id)
            
            if not oracle_student_info:
                # If student not found in Oracle, skip this participant
                skipped_students.append({
                    "student_id": student_id,
                    "reason": "Student not found in Oracle database"
                })
                continue
            
            # Prepare meta data with Oracle info
            meta = {
                "student_info": {
                    "id": participant_data.get('id', ''),
                    "department": participant_data.get('department', ''),
                    "name": participant_data.get('name', ''),
                    "grade": participant_data.get('grade', '')
                },
                "oracle_info": oracle_student_info
            }
            
            # Add teaching comments if available
            if any(key in participant_data for key in ['required_surveys', 'completed_surveys', 'surveys_completed', 'valid_surveys']):
                meta["teaching_comments"] = {
                    "required_surveys": participant_data.get('required_surveys', 0),
                    "completed_surveys": participant_data.get('completed_surveys', 0),
                    "surveys_completed": participant_data.get('surveys_completed', False),
                    "valid_surveys": participant_data.get('valid_surveys', False)
                }
            
            batch_data.append((event_id, json.dumps(meta)))
        
        # Batch insert into database
        if batch_data:
            query = """
            INSERT INTO lottery_participants (event_id, meta)
            VALUES ($1, $2)
            RETURNING id, event_id, meta, created_at
            """
            results = []
            for event_id_val, meta_json in batch_data:
                result = await Database.fetchrow(conn, query, event_id_val, meta_json)
                if result:
                    result['meta'] = LotteryDAO._parse_meta(result['meta'])
                    results.append(result)
            
            return {
                "imported": results,
                "skipped": skipped_students,
                "total_imported": len(results),
                "total_skipped": len(skipped_students)
            }
        else:
            return {
                "imported": [],
                "skipped": skipped_students,
                "total_imported": 0,
                "total_skipped": len(skipped_students)
            }

    @staticmethod
    async def get_participants(conn, event_id, limit=1000, offset=0):
        """Get participants for a lottery event"""
        query = """
        SELECT id, event_id, meta, created_at
        FROM lottery_participants
        WHERE event_id = $1
        ORDER BY id
        LIMIT $2 OFFSET $3
        """
        rows = await Database.fetch(conn, query, event_id, limit, offset)
        
        # Transform the data to flatten meta information
        participants = []
        for row in rows:
            meta = LotteryDAO._parse_meta(row['meta'])
            student_info = meta.get('student_info', {})
            teaching_comments = meta.get('teaching_comments', {})
            oracle_info = meta.get('oracle_info', {})
            
            # Prioritize Oracle name data over student_info name
            display_name = (
                oracle_info.get('name') or 
                oracle_info.get('chinese_name') or 
                oracle_info.get('english_name') or 
                student_info.get('name', '')
            )
            
            participant = {
                'id': row['id'],
                'event_id': row['event_id'],
                'created_at': row['created_at'],
                'student_id': student_info.get('id', ''),
                'department': student_info.get('department', ''),
                'name': display_name,
                'grade': student_info.get('grade', ''),
                'required_surveys': teaching_comments.get('required_surveys'),
                'completed_surveys': teaching_comments.get('completed_surveys'),
                'surveys_completed': teaching_comments.get('surveys_completed'),
                'valid_surveys': teaching_comments.get('valid_surveys'),
                # Oracle data - only include necessary fields for frontend
                'oracle_student_id': oracle_info.get('student_id', ''),
                'chinese_name': oracle_info.get('chinese_name', ''),
                'english_name': oracle_info.get('english_name', ''),
            }
            # 應用個資遮罩
            participant = apply_privacy_mask(participant)
            participants.append(participant)
        
        return participants

    @staticmethod
    async def count_participants(conn, event_id):
        """Count participants for a lottery event"""
        query = """
        SELECT COUNT(*) FROM lottery_participants
        WHERE event_id = $1
        """
        return await Database.fetchval(conn, query, event_id)

    @staticmethod
    async def create_prize(conn, event_id, name, quantity):
        """Create a prize for a lottery event"""
        query = """
        INSERT INTO lottery_prizes (event_id, name, quantity)
        VALUES ($1, $2, $3)
        RETURNING id, event_id, name, quantity, created_at
        """
        return await Database.fetchrow(conn, query, event_id, name, quantity)

    @staticmethod
    async def get_prizes(conn, event_id):
        """Get prizes for a lottery event"""
        query = """
        SELECT id, event_id, name, quantity, created_at
        FROM lottery_prizes
        WHERE event_id = $1
        ORDER BY id
        """
        return await Database.fetch(conn, query, event_id)

    @staticmethod
    async def update_prize(conn, prize_id, name, quantity):
        """Update a prize"""
        query = """
        UPDATE lottery_prizes
        SET name = $2, quantity = $3
        WHERE id = $1
        RETURNING id, event_id, name, quantity, created_at
        """
        return await Database.fetchrow(conn, query, prize_id, name, quantity)

    @staticmethod
    async def delete_prize(conn, prize_id):
        """Delete a prize"""
        query = """
        DELETE FROM lottery_prizes
        WHERE id = $1
        RETURNING id
        """
        return await Database.fetchval(conn, query, prize_id)

    @staticmethod
    async def save_winner(conn, event_id, prize_id, participant_id):
        """Save a winner"""
        query = """
        INSERT INTO lottery_winners (event_id, prize_id, participant_id)
        VALUES ($1, $2, $3)
        RETURNING id, event_id, prize_id, participant_id, created_at
        """
        return await Database.fetchrow(conn, query, event_id, prize_id, participant_id)

    @staticmethod
    async def has_winners(conn, event_id):
        """Check if an event already has winners"""
        query = """
        SELECT EXISTS (
            SELECT 1 FROM lottery_winners
            WHERE event_id = $1
        ) as has_winners
        """
        return await Database.fetchval(conn, query, event_id)

    @staticmethod
    async def get_winners(conn, event_id):
        """Get winners for a lottery event"""
        query = """
        SELECT w.id, w.event_id, w.prize_id, w.participant_id, w.created_at,
               pr.name as prize_name, p.meta
        FROM lottery_winners w
        JOIN lottery_prizes pr ON w.prize_id = pr.id
        JOIN lottery_participants p ON w.participant_id = p.id
        WHERE w.event_id = $1
        ORDER BY pr.id, w.id
        """
        rows = await Database.fetch(conn, query, event_id)
        
        # Transform the data to flatten meta information
        winners = []
        for row in rows:
            meta = LotteryDAO._parse_meta(row['meta'])
            student_info = meta.get('student_info', {})
            teaching_comments = meta.get('teaching_comments', {})
            oracle_info = meta.get('oracle_info', {})
            
            # Prioritize Oracle name data over student_info name
            display_name = (
                oracle_info.get('name') or 
                oracle_info.get('chinese_name') or 
                oracle_info.get('english_name') or 
                student_info.get('name', '')
            )
            
            winner = {
                'id': row['id'],
                'event_id': row['event_id'],
                'prize_id': row['prize_id'],
                'participant_id': row['participant_id'],
                'created_at': row['created_at'],
                'prize_name': row['prize_name'],
                'student_id': student_info.get('id', ''),
                'department': student_info.get('department', ''),
                'name': display_name,
                'grade': student_info.get('grade', ''),
                'required_surveys': teaching_comments.get('required_surveys'),
                'completed_surveys': teaching_comments.get('completed_surveys'),
                'surveys_completed': teaching_comments.get('surveys_completed'),
                'valid_surveys': teaching_comments.get('valid_surveys'),
                # Oracle data - only include necessary fields for frontend
                'oracle_student_id': oracle_info.get('student_id', ''),
                'chinese_name': oracle_info.get('chinese_name', ''),
                'english_name': oracle_info.get('english_name', ''),
            }
            # 應用個資遮罩
            winner = apply_privacy_mask(winner)
            winners.append(winner)
        
        return winners

    @staticmethod
    async def get_winners_for_export(conn, event_id):
        """Get winners for export (without privacy masking)"""
        query = """
        SELECT w.id, w.event_id, w.prize_id, w.participant_id, w.created_at,
               pr.name as prize_name, p.meta
        FROM lottery_winners w
        JOIN lottery_prizes pr ON w.prize_id = pr.id
        JOIN lottery_participants p ON w.participant_id = p.id
        WHERE w.event_id = $1
        ORDER BY pr.id, w.id
        """
        rows = await Database.fetch(conn, query, event_id)
        
        # Transform the data to flatten meta information (without privacy masking)
        winners = []
        for row in rows:
            meta = LotteryDAO._parse_meta(row['meta'])
            student_info = meta.get('student_info', {})
            teaching_comments = meta.get('teaching_comments', {})
            oracle_info = meta.get('oracle_info', {})
            
            # Prioritize Oracle name data over student_info name
            display_name = (
                oracle_info.get('name') or 
                oracle_info.get('chinese_name') or 
                oracle_info.get('english_name') or 
                student_info.get('name', '')
            )
            
            winner = {
                'id': row['id'],
                'event_id': row['event_id'],
                'prize_id': row['prize_id'],
                'participant_id': row['participant_id'],
                'created_at': row['created_at'],
                'prize_name': row['prize_name'],
                'student_id': student_info.get('id', ''),
                'department': student_info.get('department', ''),
                'name': display_name,
                'grade': student_info.get('grade', ''),
                'required_surveys': teaching_comments.get('required_surveys'),
                'completed_surveys': teaching_comments.get('completed_surveys'),
                'surveys_completed': teaching_comments.get('surveys_completed'),
                'valid_surveys': teaching_comments.get('valid_surveys'),
                # Oracle data
                'oracle_student_id': oracle_info.get('student_id', ''),
                'id_number': oracle_info.get('id_number', ''),
                'chinese_name': oracle_info.get('chinese_name', ''),
                'english_name': oracle_info.get('english_name', ''),
                'phone': oracle_info.get('phone', ''),
                'postal_code': oracle_info.get('postal_code', ''),
                'address': oracle_info.get('address', ''),
                'student_type': oracle_info.get('student_type', ''),
                'email': oracle_info.get('email', '')
            }
            # 不應用個資遮罩 - 用於 Excel 匯出
            winners.append(winner)
        
        return winners

    @staticmethod
    async def get_non_winners(conn, event_id):
        """Get participants who haven't won any prize yet"""
        query = """
        SELECT p.id as participant_id, p.event_id, p.meta, p.created_at
        FROM lottery_participants p
        LEFT JOIN lottery_winners w ON p.id = w.participant_id AND w.event_id = p.event_id
        WHERE p.event_id = $1 AND w.id IS NULL
        """
        rows = await Database.fetch(conn, query, event_id)
        
        # Transform the data to flatten meta information
        participants = []
        for row in rows:
            meta = LotteryDAO._parse_meta(row['meta'])
            student_info = meta.get('student_info', {})
            teaching_comments = meta.get('teaching_comments', {})
            oracle_info = meta.get('oracle_info', {})
            
            # Prioritize Oracle name data over student_info name
            display_name = (
                oracle_info.get('name') or 
                oracle_info.get('chinese_name') or 
                oracle_info.get('english_name') or 
                student_info.get('name', '')
            )
            
            participant = {
                'participant_id': row['participant_id'],
                'event_id': row['event_id'],
                'created_at': row['created_at'],
                'student_id': student_info.get('id', ''),
                'department': student_info.get('department', ''),
                'name': display_name,
                'grade': student_info.get('grade', ''),
                'required_surveys': teaching_comments.get('required_surveys'),
                'completed_surveys': teaching_comments.get('completed_surveys'),
                'surveys_completed': teaching_comments.get('surveys_completed'),
                'valid_surveys': teaching_comments.get('valid_surveys'),
                # Oracle data - only include necessary fields for frontend
                'oracle_student_id': oracle_info.get('student_id', ''),
                'chinese_name': oracle_info.get('chinese_name', ''),
                'english_name': oracle_info.get('english_name', ''),
            }
            # 應用個資遮罩
            participant = apply_privacy_mask(participant)
            participants.append(participant)
        
        return participants

    @staticmethod
    async def delete_winners(conn, event_id):
        """Delete all winners for an event"""
        query = """
        DELETE FROM lottery_winners
        WHERE event_id = $1
        RETURNING id
        """
        return await Database.fetch(conn, query, event_id)

    @staticmethod
    async def delete_participant(conn, participant_id):
        """Delete a specific participant"""
        query = """
        DELETE FROM lottery_participants
        WHERE id = $1
        RETURNING id, event_id
        """
        return await Database.fetchrow(conn, query, participant_id)

    @staticmethod
    async def delete_all_participants(conn, event_id):
        """Delete all participants for an event"""
        query = """
        DELETE FROM lottery_participants
        WHERE event_id = $1
        RETURNING id
        """
        return await Database.fetch(conn, query, event_id)

    @staticmethod
    async def soft_delete_event(conn, event_id):
        """Soft delete a lottery event by setting is_deleted to TRUE"""
        query = """
        UPDATE lottery_events
        SET is_deleted = TRUE
        WHERE id = $1 AND is_deleted = FALSE
        RETURNING id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
        """
        return await Database.fetchrow(conn, query, event_id)

    @staticmethod
    async def restore_event(conn, event_id):
        """Restore a soft deleted lottery event by setting is_deleted to FALSE"""
        query = """
        UPDATE lottery_events
        SET is_deleted = FALSE
        WHERE id = $1 AND is_deleted = TRUE
        RETURNING id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
        """
        return await Database.fetchrow(conn, query, event_id)

    @staticmethod
    async def get_deleted_events(conn, limit=100, offset=0):
        """Get all soft deleted lottery events with pagination"""
        query = """
        SELECT id, academic_year_term, name, description, event_date, type, status, is_deleted, created_at
        FROM lottery_events
        WHERE is_deleted = TRUE
        ORDER BY created_at DESC
        LIMIT $1 OFFSET $2
        """
        return await Database.fetch(conn, query, limit, offset) 